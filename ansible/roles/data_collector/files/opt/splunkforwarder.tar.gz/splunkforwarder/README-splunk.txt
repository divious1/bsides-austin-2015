
Splunk 6.2.2
February, 2015
Splunk Enterprise and Splunk Light are the data collection, indexing, and visualization engine for operational intelligence.

Splunk online documentation is located at:
* Splunk Enterprise: http://docs.splunk.com/Documentation/Splunk
* Splunk Light: http://docs.splunk.com/Documentation/SplunkLight

For installation and set-up instructions, refer to the Installation Manuals:
* Splunk Enterprise: http://docs.splunk.com/Documentation/Splunk/latest/Installation
* Splunk Light: http://docs.splunk.com/Documentation/SplunkLight/latest/Installation

For release notes, refer to the Known issues in the Release Notes manual:
* Splunk Enterprise: http://docs.splunk.com/Documentation/Splunk/latest/ReleaseNotes/Knownissues
* Splunk Light: http://docs.splunk.com/Documentation/SplunkLight/latest/ReleaseNotes/Knownissues

